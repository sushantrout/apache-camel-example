package com.tech.camelmicroservicetwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelMicroserviceTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelMicroserviceTwoApplication.class, args);
	}

}
